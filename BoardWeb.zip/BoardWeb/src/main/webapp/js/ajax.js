/**
 * ajax.js
 * Asynchronous Javascript And Xml. 
 */

setTimeout(function() {
 console.log('a');	
}, 1000);

setTimeout(function() {
 console.log('b');	
}, 1000);

setTimeout(function() {
 console.log('c');	
}, 1000);

// console.log('b');
// console.log('c');
 